#include<iostream>
#include<vector>
#include<algorithm>
#include<fstream>
using namespace std;


	int main(int argc, char **argv){
		if(argc== 1){
			cerr<<"File name or path not found\n"; 
		}
		
		ifstream arq(argv[1]); 
		
		vector<vector<double> > distanceMatrix; 
		int numPoints; 
		
		arq>>numPoints;
		distanceMatrix.resize(numPoints); 
		for(int i=0; i<numPoints; i++){
			distanceMatrix[i].resize(numPoints); 
			for(int j=0;j<numPoints;j++)
				arq>>distanceMatrix[i][j];
		}
		
		arq.close(); 
				
		vector<int> currentSolution;
		vector<int> bestSolution; 
		double bestSolutionValue = 1e100; 
		
		
		for(int i=0;i<numPoints;i++)
			currentSolution.push_back(i+1); 
		
		//Try all the possible permutations of points 
		while(next_permutation(currentSolution.begin(), currentSolution.end())){
			double cost = 0; 
			
			//Evaluate solution
			for(int i=1; i<currentSolution.size();i++)
				cost += distanceMatrix[i-1][i];
			
			//Update best solution
			if(cost < bestSolutionValue){
				bestSolutionValue = cost; 
				bestSolution = currentSolution; 
			}
		}
		
		ofstream output("exit.txt");
		for(int i=0;i<numPoints;i++){
			output<<bestSolution[i]<<" "; 
		}
		
		return 0; 
	}